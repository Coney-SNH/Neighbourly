import React from 'react'

const Payments = () => {
    return (
         <div >
        <h1 > Your payment methods! </h1> 
        </div>
    )
}

export default Payments;