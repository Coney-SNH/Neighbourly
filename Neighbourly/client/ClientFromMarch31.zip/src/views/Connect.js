import React from 'react'

const Connect = () => {
    return (
        <div>
            <h1>You can Connect now! Send a Message</h1>
        </div>
    )
}

export default Connect

