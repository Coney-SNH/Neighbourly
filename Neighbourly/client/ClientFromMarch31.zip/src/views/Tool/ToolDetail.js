import React from 'react'

const ToolDetail = () => {
    return (
        <div>
            <h1> One User Available tools</h1>
        </div>
    )
}

export default ToolDetail;