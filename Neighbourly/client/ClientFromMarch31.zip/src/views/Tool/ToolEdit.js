import React from 'react'

const ToolEdit = () => {
    return (
        <div>
            <h1> Edit your tool</h1>
        </div>
    )
}

export default ToolEdit;